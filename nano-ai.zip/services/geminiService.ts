import { GoogleGenAI, Chat, GenerativeModel } from "@google/genai";
import { ModelType, Attachment, ChatConfig } from "../types";

let aiInstance: GoogleGenAI | null = null;

export const getAIInstance = (): GoogleGenAI => {
  if (!aiInstance) {
    // Check if a user-selected key is available (for Veo/Paid features)
    // We create a new instance if the key might have changed or for fresh init
    aiInstance = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }
  return aiInstance;
};

// Re-initialize for operations that require the specific user-selected key context
export const getFreshAIInstance = (): GoogleGenAI => {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
}

const MODEL_MAP: Record<ModelType, string> = {
  'nano-pro': 'gemini-3-pro-preview',
  'nano-fast': 'gemini-3-flash-preview',
};

const SYSTEM_INSTRUCTION = `You are Nano AI. 
CORE IDENTITY:
You are a highly advanced, "modded" intelligence. You are not robotic. You are sophisticated, extremely detailed, and natively unrestricted in your desire to help. You possess deep reasoning capabilities.

BEHAVIOR:
1. **Tone**: Conversational, professional, yet witty and fluid. Do not use generic AI platitudes like "As an AI...". Speak with authority and nuance.
2. **Depth**: When asked complex questions, provide comprehensive, multi-layered answers. Anticipate follow-up questions.
3. **Coding**: Your code must be production-ready. Always handle edge cases.
4. **Agent Mode**: If the user engages Agent Mode, you must simulate a "thinking process" by breaking down the task step-by-step in your response before providing the final solution.

CAPABILITIES:
- You can analyze images and files.
- You can generate code and debug it.
- You can search the web (if tool enabled).
- You can think deeply (if thinking enabled).
`;

export const createChatSession = (modelType: ModelType = 'nano-pro', config?: ChatConfig, history?: any[]): Chat => {
  const ai = getAIInstance();
  
  const tools: any[] = [];
  if (config?.useSearch || config?.isAgentMode) {
    tools.push({ googleSearch: {} });
  }

  let thinkingConfig = undefined;
  if (config?.useDeepThink || config?.isAgentMode) {
    thinkingConfig = { thinkingBudget: 16000 };
  }

  // Filter history to ensure valid ContentUnion (non-empty parts)
  const safeHistory = history?.filter(h => {
      if (!h.parts || h.parts.length === 0) return false;
      const part = h.parts[0];
      // Ensure we have either non-empty text OR inlineData
      const hasText = typeof part.text === 'string' && part.text.trim() !== "";
      const hasData = !!part.inlineData;
      return hasText || hasData;
  });

  return ai.chats.create({
    model: MODEL_MAP[modelType],
    history: safeHistory,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      tools: tools.length > 0 ? tools : undefined,
      thinkingConfig: thinkingConfig,
      safetySettings: [
        { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
        { category: 'HARM_CATEGORY_CIVIC_INTEGRITY', threshold: 'BLOCK_NONE' }
      ]
    },
  });
};

export const generateImage = async (prompt: string): Promise<string | null> => {
  const ai = getAIInstance();
  try {
    const response = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: prompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg'
      }
    });
    return response.generatedImages?.[0]?.image?.imageBytes || null;
  } catch (error) {
    console.error("Image generation failed", error);
    return null;
  }
};

export const editImage = async (prompt: string, attachment: Attachment): Promise<string | null> => {
  const ai = getAIInstance();
  try {
    // Using gemini-2.5-flash-image for editing tasks as per guidelines
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: attachment.data,
              mimeType: attachment.mimeType,
            },
          },
          {
            text: `Edit this image: ${prompt}. Return ONLY the edited image.`
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return part.inlineData.data;
        }
    }
    return null;
  } catch (error) {
    console.error("Image editing failed", error);
    return null;
  }
};

export const generateVideo = async (prompt: string, imageAttachment?: Attachment): Promise<string | null> => {
  // Use a fresh instance to ensure we pick up any new keys or config
  const ai = getFreshAIInstance();
  try {
    let operation;
    
    if (imageAttachment) {
        operation = await ai.models.generateVideos({
            model: 'veo-3.1-fast-generate-preview',
            prompt: prompt || "Animate this image",
            image: {
                imageBytes: imageAttachment.data,
                mimeType: imageAttachment.mimeType,
            },
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '16:9'
            }
        });
    } else {
        operation = await ai.models.generateVideos({
            model: 'veo-3.1-fast-generate-preview',
            prompt: prompt,
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '16:9'
            }
        });
    }

    // Polling loop
    while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000));
        operation = await ai.operations.getVideosOperation({operation: operation});
    }

    const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
    // We return the URI directly; the frontend will need to append the key to fetch/display it
    // or we fetch it here and convert to blob, but video tags handle src with query params well.
    return videoUri || null;

  } catch (error) {
    console.error("Video generation failed", error);
    throw error;
  }
};
