export interface Attachment {
  mimeType: string;
  data: string; // base64
  name?: string;
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  isStreaming?: boolean;
  timestamp: number;
  attachments?: Attachment[];
  groundingMetadata?: {
    groundingChunks: GroundingChunk[];
  };
  generatedImage?: string; // base64
  generatedVideo?: string; // uri
  isThinking?: boolean; // For agent mode visualization
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  lastModified: number;
}

export type ModelType = 'nano-pro' | 'nano-fast';

export interface ChatConfig {
  useSearch: boolean;
  useDeepThink: boolean;
  isAgentMode: boolean;
}
