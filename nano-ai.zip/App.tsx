import React, { useState, useEffect, useRef } from 'react';
import { Chat, GenerateContentResponse } from "@google/genai";
import { Message, ChatSession, ModelType, Attachment, ChatConfig } from './types';
import { createChatSession, generateImage, generateVideo, editImage, getAIInstance } from './services/geminiService';
import { ChatMessage } from './components/ChatMessage';
import { InputArea } from './components/InputArea';

const generateId = () => Math.random().toString(36).substring(2, 15);

const getGreeting = () => {
  const hour = new Date().getHours();
  let timeGreeting = "Good Morning";
  if (hour >= 12 && hour < 17) timeGreeting = "Good Afternoon";
  if (hour >= 17) timeGreeting = "Good Evening";
  if (hour >= 22 || hour < 5) timeGreeting = "Good Night";
  
  return `${timeGreeting}. Nano AI is online. Systems optimized.`;
};

const App: React.FC = () => {
  // State
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [currentModel, setCurrentModel] = useState<ModelType>('nano-pro');
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  // Agent Mode State Visualization
  const [isAgentThinking, setIsAgentThinking] = useState(false);

  // Renaming State
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  
  // Refs
  const chatSessionRef = useRef<Chat | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  // Initialize
  useEffect(() => {
    const savedSessions = localStorage.getItem('nano_sessions');
    if (savedSessions) {
      try {
        const parsed = JSON.parse(savedSessions);
        setSessions(parsed);
        if (parsed.length > 0) {
          setCurrentSessionId(parsed[0].id);
        } else {
          createNewSession();
        }
      } catch (e) {
        createNewSession();
      }
    } else {
      createNewSession();
    }
  }, []);

  // Persist sessions
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem('nano_sessions', JSON.stringify(sessions));
    }
  }, [sessions]);

  // Update chat instance when model changes
  useEffect(() => {
    // We do not pass history here on init, we will do it on sendMessage
    // to keep it synced.
    // chatSessionRef.current = createChatSession(currentModel);
  }, [currentModel]);

  // Scroll to bottom
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentSessionId, sessions, isAgentThinking]);

  const currentSession = sessions.find(s => s.id === currentSessionId);
  const messages = currentSession?.messages || [];

  const createNewSession = () => {
    const newSession: ChatSession = {
      id: generateId(),
      title: 'New Chat',
      messages: [{
        id: 'welcome',
        role: 'model',
        content: getGreeting(),
        timestamp: Date.now()
      }],
      lastModified: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    setEditingSessionId(null);
    setEditTitle('');
  };

  const deleteSession = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const newSessions = sessions.filter(s => s.id !== id);
    setSessions(newSessions);
    if (currentSessionId === id) {
      if (newSessions.length > 0) {
        setCurrentSessionId(newSessions[0].id);
      } else {
        createNewSession();
      }
    }
    localStorage.setItem('nano_sessions', JSON.stringify(newSessions));
  };

  const startEditing = (e: React.MouseEvent, session: ChatSession) => {
    e.stopPropagation();
    setEditingSessionId(session.id);
    setEditTitle(session.title);
  };

  const saveSessionTitle = () => {
    if (editingSessionId) {
      const newTitle = editTitle.trim() || 'Untitled Chat';
      setSessions(prev => prev.map(s => 
        s.id === editingSessionId ? { ...s, title: newTitle } : s
      ));
      setEditingSessionId(null);
      setEditTitle('');
    }
  };

  const handleEditKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      saveSessionTitle();
    } else if (e.key === 'Escape') {
      setEditingSessionId(null);
      setEditTitle('');
    }
  };

  const updateSessionMessages = (sessionId: string, newMessages: Message[]) => {
    setSessions(prev => prev.map(s => {
      if (s.id === sessionId) {
        let title = s.title;
        if (s.title === 'New Chat' && s.messages.length <= 1 && newMessages.length > 1) {
           const userMsg = newMessages.find(m => m.role === 'user');
           if (userMsg) {
             title = userMsg.content.slice(0, 30) + (userMsg.content.length > 30 ? '...' : '');
           }
        }
        return { ...s, messages: newMessages, title, lastModified: Date.now() };
      }
      return s;
    }));
  };

  const handleAutoFix = (code: string) => {
    const prompt = `Review the following code for errors, fix them, and explain the solution:\n\n${code}`;
    handleSendMessage(prompt, [], { useSearch: false, useDeepThink: true, isAgentMode: false });
  };

  const checkVeoKey = async (): Promise<boolean> => {
      try {
          const aistudio = (window as any).aistudio;
          if (aistudio && aistudio.hasSelectedApiKey) {
              const hasKey = await aistudio.hasSelectedApiKey();
              if (!hasKey) {
                  await aistudio.openSelectKey();
                  return true; // Assume success after modal interaction
              }
              return true;
          }
      } catch (e) {
          console.error("Error checking Veo key", e);
          return false;
      }
      return true; // Fallback for dev if mock missing
  };

  const handleSendMessage = async (text: string, attachments: Attachment[], config: ChatConfig) => {
    if (!currentSessionId) return;

    // Detection Logic
    const lowerText = text.toLowerCase();
    const isImageGeneration = lowerText.startsWith('/image') || 
                              (lowerText.includes('generate') && lowerText.includes('image'));
    const isVideoGeneration = lowerText.startsWith('/video') || 
                              (lowerText.includes('generate') && lowerText.includes('video'));
    // Heuristic for image editing: has attachment AND words like edit, change, make it
    const isImageEditing = attachments.length > 0 && 
                           attachments.some(a => a.mimeType.startsWith('image/')) &&
                           (lowerText.includes('edit') || lowerText.includes('change') || lowerText.includes('make it') || lowerText.includes('transform'));

    setIsLoading(true);
    if (config.isAgentMode) setIsAgentThinking(true);

    const userMessage: Message = {
      id: generateId(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
      attachments: attachments
    };

    const updatedMessages = [...messages, userMessage];
    updateSessionMessages(currentSessionId, updatedMessages);

    try {
      if (isVideoGeneration) {
         // Video Generation
         const hasKey = await checkVeoKey();
         if (!hasKey) throw new Error("API Key selection required for Video generation.");

         const imageAttachment = attachments.find(a => a.mimeType.startsWith('image/'));
         const videoUri = await generateVideo(text, imageAttachment);
         
         if (videoUri) {
            updateSessionMessages(currentSessionId, [
                ...updatedMessages,
                {
                    id: generateId(),
                    role: 'model',
                    content: "Video sequence generated successfully.",
                    timestamp: Date.now(),
                    generatedVideo: videoUri
                }
             ]);
         } else {
             throw new Error("Video generation returned no URI.");
         }

      } else if (isImageEditing) {
         // Image Editing
         const targetImage = attachments.find(a => a.mimeType.startsWith('image/'));
         if (targetImage) {
             const editedImageBase64 = await editImage(text, targetImage);
             if (editedImageBase64) {
                 updateSessionMessages(currentSessionId, [
                    ...updatedMessages,
                    {
                        id: generateId(),
                        role: 'model',
                        content: "Image modification complete.",
                        timestamp: Date.now(),
                        generatedImage: editedImageBase64
                    }
                 ]);
             } else {
                 throw new Error("Image editing failed.");
             }
         } else {
             throw new Error("No image found to edit.");
         }

      } else if (isImageGeneration) {
         // Image Generation
         const imageBase64 = await generateImage(text);
         if (imageBase64) {
             updateSessionMessages(currentSessionId, [
                ...updatedMessages,
                {
                    id: generateId(),
                    role: 'model',
                    content: "Processing visualization request complete. Output generated.",
                    timestamp: Date.now(),
                    generatedImage: imageBase64
                }
             ]);
         } else {
             throw new Error("Image generation failed");
         }

      } else {
          // Standard Chat (Text/Multimodal)
          
          // Prepare History: Exclude current user message from history, as we will send it.
          const formattedHistory = messages.map(m => ({
            role: m.role,
            parts: m.attachments 
              ? [...m.attachments.map(a => ({ inlineData: { mimeType: a.mimeType, data: a.data } })), { text: m.content || " " }] // Ensure content is not empty string if attachments exist
              : [{ text: m.content || " " }]
          }));

          const activeChat = createChatSession(currentModel, config, formattedHistory);

          // Prepare current message parts
          let sendParts: any;
          if (attachments.length > 0) {
              sendParts = [
                  ...attachments.map(a => ({ inlineData: { mimeType: a.mimeType, data: a.data } })),
                  { text: text || " " } // Ensure text part exists
              ];
          } else {
              // Just text
              sendParts = text || " ";
          }
          
          // Wrap sendParts in an object with 'message' property
          const streamResult = await activeChat.sendMessageStream({ message: sendParts });

          const modelMessageId = generateId();
          let fullResponseText = "";
          let groundingMetadata = undefined;
          
          updateSessionMessages(currentSessionId, [
            ...updatedMessages, 
            {
              id: modelMessageId,
              role: 'model',
              content: '',
              isStreaming: true,
              timestamp: Date.now()
            }
          ]);

          for await (const chunk of streamResult) {
            const c = chunk as GenerateContentResponse;
            const textChunk = c.text || "";
            fullResponseText += textChunk;
            
            if (c.candidates?.[0]?.groundingMetadata) {
               groundingMetadata = c.candidates[0].groundingMetadata;
            }

            setSessions(prev => prev.map(s => {
              if (s.id === currentSessionId) {
                return {
                  ...s,
                  messages: s.messages.map(m => 
                    m.id === modelMessageId ? { 
                        ...m, 
                        content: fullResponseText,
                        groundingMetadata: groundingMetadata || m.groundingMetadata 
                    } : m
                  )
                };
              }
              return s;
            }));
          }

          setSessions(prev => prev.map(s => {
            if (s.id === currentSessionId) {
              return {
                ...s,
                messages: s.messages.map(m => 
                  m.id === modelMessageId ? { ...m, isStreaming: false } : m
                )
              };
            }
            return s;
          }));
      }

    } catch (error) {
      console.error("Error sending message:", error);
      updateSessionMessages(currentSessionId, [
        ...updatedMessages,
        {
          id: generateId(),
          role: 'model',
          content: "System Alert: Complex task execution failed. Error log: " + (error instanceof Error ? error.message : String(error)),
          timestamp: Date.now()
        }
      ]);
    } finally {
      setIsLoading(false);
      setIsAgentThinking(false);
    }
  };

  return (
    <div className="flex h-screen bg-background text-zinc-200 overflow-hidden font-sans selection:bg-indigo-500/30 selection:text-white">
      
      {/* Sidebar */}
      <aside 
        className={`${isSidebarOpen ? 'w-64' : 'w-0'} flex-shrink-0 bg-[#050505] border-r border-border transition-all duration-300 overflow-hidden flex flex-col relative`}
      >
        <div className="p-4 flex items-center justify-between border-b border-border/50">
           <button 
             onClick={createNewSession}
             className="w-full flex items-center gap-2 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded-md text-sm text-zinc-300 transition-colors"
           >
             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
               <path d="M10.75 4.75a.75.75 0 00-1.5 0v4.5h-4.5a.75.75 0 000 1.5h4.5v4.5a.75.75 0 001.5 0v-4.5h4.5a.75.75 0 000-1.5h-4.5v-4.5z" />
             </svg>
             <span>New Chat</span>
           </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-hide">
           {sessions.map(session => (
             <div 
               key={session.id}
               onClick={() => setCurrentSessionId(session.id)}
               className={`group flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer text-sm transition-all ${
                 currentSessionId === session.id 
                   ? 'bg-zinc-800 text-white' 
                   : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900'
               }`}
             >
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 flex-shrink-0">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.35.026.67.21.865.501L12 21l2.755-4.133a1.14 1.14 0 01.865-.501 48.172 48.172 0 003.423-.379c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z" />
                </svg>

                {editingSessionId === session.id ? (
                  <input 
                    autoFocus
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    onBlur={saveSessionTitle}
                    onKeyDown={handleEditKeyDown}
                    onClick={(e) => e.stopPropagation()}
                    className="flex-1 bg-transparent border-b border-indigo-500 focus:outline-none font-mono text-xs text-white min-w-0"
                  />
                ) : (
                  <span className="truncate flex-1 font-mono text-xs">{session.title}</span>
                )}
                
                {editingSessionId !== session.id && (
                  <div className="opacity-0 group-hover:opacity-100 flex items-center gap-0.5">
                    <button 
                      onClick={(e) => startEditing(e, session)}
                      className="p-1 text-zinc-500 hover:text-white hover:bg-zinc-700/50 rounded transition-colors"
                      title="Rename"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5">
                        <path d="M5.433 13.917l1.262-3.155A4 4 0 017.58 9.42l6.92-6.918a2.121 2.121 0 013 3l-6.92 6.918c-.383.383-.84.685-1.343.886l-3.154 1.262a.5.5 0 01-.65-.65z" />
                        <path d="M3.5 5.75c0-.69.56-1.25 1.25-1.25H10A.75.75 0 0010 3H4.75A2.75 2.75 0 002 5.75v9.5A2.75 2.75 0 004.75 18h9.5A2.75 2.75 0 0017 15.25V10a.75.75 0 00-1.5 0v5.25c0 .69-.56 1.25-1.25 1.25h-9.5c-.69 0-1.25-.56-1.25-1.25v-9.5z" />
                      </svg>
                    </button>
                    <button 
                      onClick={(e) => deleteSession(e, session.id)}
                      className="p-1 text-zinc-500 hover:text-red-400 hover:bg-zinc-700/50 rounded transition-colors"
                      title="Delete"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5">
                        <path fillRule="evenodd" d="M8.75 1A2.75 2.75 0 006 3.75v.443c-.795.077-1.584.176-2.365.298a.75.75 0 10.23 1.482l.149.022.841 10.518A2.75 2.75 0 007.596 19h4.807a2.75 2.75 0 002.742-2.53l.841-10.52.149-.023a.75.75 0 00.23-1.482A41.03 41.03 0 0014 4.193V3.75A2.75 2.75 0 0011.25 1h-2.5zM10 4c.84 0 1.673.025 2.5.075V3.75c0-.69-.56-1.25-1.25-1.25h-2.5c-.69 0-1.25.56-1.25 1.25v.325C8.327 4.025 9.16 4 10 4zM8.58 7.72a.75.75 0 00-1.5.06l.3 7.5a.75.75 0 101.5-.06l-.3-7.5zm4.34.06a.75.75 0 10-1.5-.06l-.3 7.5a.75.75 0 101.5.06l.3-7.5z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                )}
             </div>
           ))}
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full relative">
        {/* Header */}
        <header className="flex-shrink-0 h-14 border-b border-border bg-surface/80 backdrop-blur-md flex items-center justify-between px-4 sticky top-0 z-50">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-1.5 hover:bg-zinc-800 rounded-md text-zinc-400 hover:text-white transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
              </svg>
            </button>
            <div className="flex items-center gap-2.5 select-none">
              <img 
                src="https://registry.npmmirror.com/@lobehub/icons-static-png/latest/files/dark/gemini-color.png" 
                alt="Logo" 
                className="w-6 h-6 object-contain"
              />
              <h1 className="font-mono font-bold text-sm tracking-wider text-white">Nano AI <span className="text-zinc-600 font-normal">Studio</span></h1>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
             {/* Model Selector */}
             <div className="relative group">
                <select 
                  value={currentModel}
                  onChange={(e) => {
                    setCurrentModel(e.target.value as ModelType);
                    createNewSession(); 
                  }}
                  className="appearance-none bg-zinc-900 border border-border text-zinc-300 text-xs font-mono py-1.5 pl-3 pr-8 rounded-md focus:outline-none focus:border-zinc-700 cursor-pointer hover:bg-zinc-800 transition-colors"
                >
                  <option value="nano-pro">nano-pro</option>
                  <option value="nano-fast">nano-fast</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-zinc-500">
                  <svg className="fill-current h-3 w-3" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
             </div>
          </div>
        </header>

        {/* Chat Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth relative">
          <div className="max-w-4xl mx-auto flex flex-col min-h-full justify-end">
            <div className="space-y-0 pb-4">
               {messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} onFixCode={handleAutoFix} />
              ))}
              
              {/* Agent Mode Thinking Indicator */}
              {isAgentThinking && (
                 <div className="mb-8 border border-red-900/50 bg-red-900/10 rounded-lg p-4 animate-pulse">
                    <div className="flex items-center gap-2 mb-2 text-red-400 font-mono text-xs uppercase tracking-widest">
                       <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                        </span>
                       Agent Mode Active
                    </div>
                    <div className="space-y-2">
                       <div className="h-1 bg-red-900/20 rounded w-3/4"></div>
                       <div className="h-1 bg-red-900/20 rounded w-1/2"></div>
                       <p className="text-xs text-zinc-500 font-mono mt-2">Thinking deeply... Analysing request... Generating solution...</p>
                    </div>
                 </div>
              )}

              {isLoading && !isAgentThinking && !messages[messages.length - 1]?.isStreaming && (
                <div className="flex items-center gap-2 mb-8 animate-pulse px-6">
                   <div className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]" />
                   <span className="text-xs font-mono text-zinc-600">Nano AI is thinking...</span>
                </div>
              )}
            </div>
            <div ref={bottomRef} className="h-4" />
          </div>
          
          {/* Background Grid */}
          <div className="absolute inset-0 pointer-events-none opacity-[0.03] z-[-1]" 
               style={{
                 backgroundImage: `linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)`,
                 backgroundSize: '40px 40px'
               }}>
          </div>
        </main>

        <footer className="flex-shrink-0 bg-background pt-2 z-10 border-t border-transparent">
          <InputArea onSendMessage={handleSendMessage} disabled={isLoading} />
        </footer>
      </div>

    </div>
  );
};

export default App;