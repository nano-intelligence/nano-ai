import React, { useState, useRef, useEffect } from 'react';
import { Attachment, ChatConfig } from '../types';

interface InputAreaProps {
  onSendMessage: (message: string, attachments: Attachment[], config: ChatConfig) => void;
  disabled: boolean;
}

export const InputArea: React.FC<InputAreaProps> = ({ onSendMessage, disabled }) => {
  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  
  // Toggles
  const [useSearch, setUseSearch] = useState(false);
  const [useDeepThink, setUseDeepThink] = useState(false);
  const [isAgentMode, setIsAgentMode] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if ((input.trim() || attachments.length > 0) && !disabled) {
      onSendMessage(input.trim(), attachments, {
        useSearch: useSearch || isAgentMode, // Agent mode implies search
        useDeepThink: useDeepThink || isAgentMode, // Agent mode implies thinking
        isAgentMode
      });
      setInput('');
      setAttachments([]);
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newAttachments: Attachment[] = [];
      const files: File[] = Array.from(e.target.files);

      for (const file of files) {
          const reader = new FileReader();
          await new Promise<void>((resolve) => {
              reader.onload = (event) => {
                  if (event.target?.result) {
                      const base64String = (event.target.result as string).split(',')[1];
                      newAttachments.push({
                          mimeType: file.type,
                          data: base64String,
                          name: file.name
                      });
                  }
                  resolve();
              };
              reader.readAsDataURL(file);
          });
      }
      
      setAttachments(prev => [...prev, ...newAttachments]);
    }
    // Reset input so same file can be selected again
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const toggleAgentMode = () => {
    const newState = !isAgentMode;
    setIsAgentMode(newState);
    if (newState) {
      setUseSearch(true);
      setUseDeepThink(true);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6">
      <form 
        onSubmit={handleSubmit}
        className={`relative group transition-all duration-300 ${disabled ? 'opacity-70' : 'opacity-100'}`}
      >
        {/* Toolbar */}
        <div className="flex items-center gap-2 mb-2 px-1">
          <button
            type="button"
            onClick={() => setUseSearch(!useSearch)}
            disabled={isAgentMode}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono border transition-all ${
              useSearch || isAgentMode
                ? 'bg-blue-900/30 text-blue-300 border-blue-500/50' 
                : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-zinc-700'
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
              <path fillRule="evenodd" d="M9 3.5a5.5 5.5 0 100 11 5.5 5.5 0 000-11zM2 9a7 7 0 1112.452 4.391l3.328 3.329a.75.75 0 11-1.06 1.06l-3.329-3.328A7 7 0 012 9z" clipRule="evenodd" />
            </svg>
            Search
          </button>
          
          <button
            type="button"
            onClick={() => setUseDeepThink(!useDeepThink)}
            disabled={isAgentMode}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono border transition-all ${
              useDeepThink || isAgentMode
                ? 'bg-purple-900/30 text-purple-300 border-purple-500/50' 
                : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-zinc-700'
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
              <path fillRule="evenodd" d="M10 2c-1.716 0-3.408.106-5.07.31C3.806 2.45 3 3.414 3 4.517V17.25a.75.75 0 001.075.676L10 15.082l5.925 2.844A.75.75 0 0017 17.25V4.517c0-1.103-.806-2.068-1.93-2.207A41.403 41.403 0 0010 2z" clipRule="evenodd" />
            </svg>
            DeepThink
          </button>

          <button
            type="button"
            onClick={toggleAgentMode}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono border transition-all ml-auto ${
              isAgentMode 
                ? 'bg-red-900/30 text-red-300 border-red-500/50 shadow-[0_0_10px_rgba(239,68,68,0.2)]' 
                : 'bg-zinc-900 text-zinc-500 border-zinc-800 hover:border-zinc-700'
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
              <path d="M10 2a.75.75 0 01.75.75v1.5h1.5a.75.75 0 010 1.5h-1.5v2h2V6.25a.75.75 0 011.5 0V7.75h.75a.75.75 0 010 1.5h-.75v1.5a.75.75 0 01-1.5 0v-1.5h-2v2h1.5a.75.75 0 010 1.5h-1.5v1.5a.75.75 0 01-1.5 0v-1.5h-1.5a.75.75 0 010-1.5h1.5v-2h-2v1.5a.75.75 0 01-1.5 0V10.75h-.75a.75.75 0 010-1.5h.75v-1.5a.75.75 0 011.5 0v1.5h2v-2h-1.5a.75.75 0 010-1.5h1.5v-1.5A.75.75 0 0110 2z" />
            </svg>
            Agent Mode
          </button>
        </div>

        <div className="relative flex flex-col bg-surfaceHighlight rounded-xl border border-border focus-within:border-zinc-600 transition-colors shadow-2xl">
          {/* Attachments Preview */}
          {attachments.length > 0 && (
            <div className="flex gap-2 p-3 pb-0 overflow-x-auto">
              {attachments.map((file, idx) => (
                <div key={idx} className="relative group bg-zinc-800 rounded-lg p-2 flex items-center gap-2 border border-zinc-700">
                  <div className="text-xs text-zinc-300 max-w-[100px] truncate">{file.name || 'File'}</div>
                  <button 
                    type="button"
                    onClick={() => removeAttachment(idx)}
                    className="text-zinc-500 hover:text-red-400"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                      <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          )}

          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={disabled}
            placeholder={isAgentMode ? "Assign a complex task for Agent Nano..." : "Enter text, drop images/files, or ask to generate video..."}
            className="w-full bg-transparent text-zinc-200 placeholder-zinc-600 text-base font-mono p-4 max-h-[200px] min-h-[60px] resize-none focus:outline-none scrollbar-hide"
            rows={1}
            spellCheck={false}
          />
          <div className="flex justify-between items-center px-3 pb-3">
             <div className="flex items-center gap-2">
                <input 
                  type="file" 
                  ref={fileInputRef}
                  className="hidden" 
                  onChange={handleFileSelect}
                  multiple={true}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="p-1.5 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 rounded-md transition-colors"
                  title="Upload Files"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 6.187l-5.123 5.122" />
                  </svg>
                </button>
                <span className="hidden sm:inline text-[10px] text-zinc-600 font-mono">Shift + Enter for new line</span>
             </div>
             
             <button
              type="submit"
              disabled={(!input.trim() && attachments.length === 0) || disabled}
              className={`p-2 rounded-lg text-black transition-all active:scale-95 flex items-center justify-center shadow-[0_0_10px_rgba(255,255,255,0.1)] ${
                isAgentMode 
                  ? 'bg-red-500 hover:bg-red-400 disabled:bg-zinc-800 disabled:text-zinc-600'
                  : 'bg-zinc-100 hover:bg-white disabled:bg-zinc-800 disabled:text-zinc-600'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z" />
              </svg>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};