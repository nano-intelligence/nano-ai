import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Message } from '../types';
import clsx from 'clsx';

interface ChatMessageProps {
  message: Message;
  onFixCode?: (code: string) => void;
}

const CodeBlock = ({ children, className, onFixCode, ...props }: any) => {
  const [copied, setCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // Extract code text from children
  const codeContent = String(children).replace(/\n$/, '');
  
  // Simple language detection from class name
  const match = /language-(\w+)/.exec(className || '');
  const language = match ? match[1] : '';

  const handleCopy = async () => {
    await navigator.clipboard.writeText(codeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // If no language class and inline, render as inline code
  if (!match && !codeContent.includes('\n')) {
    return <code className="bg-surfaceHighlight px-1.5 py-0.5 rounded text-sm font-mono text-zinc-300" {...props}>{children}</code>;
  }

  const containerClass = isFullscreen 
    ? "fixed inset-0 z-[100] bg-[#09090b] flex flex-col p-4 md:p-10" 
    : "group my-4 rounded-lg border border-border overflow-hidden bg-surface";

  const headerClass = isFullscreen
    ? "flex items-center justify-between px-4 py-3 bg-surfaceHighlight border-b border-border mb-4 rounded-t-lg"
    : "flex items-center justify-between px-4 py-2 bg-surfaceHighlight border-b border-border";

  return (
    <div className={containerClass}>
      <div className={headerClass}>
        <div className="flex items-center gap-3">
          <span className="text-xs font-mono text-zinc-500 lowercase">{language || 'code'}</span>
          {onFixCode && (
            <button 
              onClick={() => onFixCode(codeContent)}
              className="flex items-center gap-1 px-2 py-0.5 rounded bg-red-500/10 text-red-400 hover:bg-red-500/20 text-[10px] border border-red-500/30 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
                <path fillRule="evenodd" d="M19 5.5a4.5 4.5 0 01-4.791 4.49c-.873-.055-1.808.128-2.368.8l-6.024 7.23a.75.75 0 01-1.064.096l-2.302-1.919a.75.75 0 01-.096-1.064l6.191-7.429c.6-.72.622-1.631.325-2.423A4.5 4.5 0 0113.5 1h1.75a.75.75 0 01.75.75V3c0 1.257.65 2.373 1.637 3.04.143.096.225.26.225.433v3.744a.75.75 0 01-1.302.53l-1.302-1.302a2.992 2.992 0 01-.877-2.122v-.75H13.5a3 3 0 00-3 3c0 .59.162 1.14.444 1.62.13.22.128.497-.006.715l-6.429 10.5A.75.75 0 013.75 19h12.5a.75.75 0 00.75-.75v-10.5a.75.75 0 00-.22-.53l-2.62-2.62z" clipRule="evenodd" />
              </svg>
              Auto-Fix
            </button>
          )}
        </div>
        
        <div className="flex items-center gap-2">
           <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="text-xs text-zinc-400 hover:text-white transition-colors"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
          >
             {isFullscreen ? (
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                  <path d="M3.25 4A.75.75 0 004 4.75h4.5a.75.75 0 000-1.5H4.81l3.97-3.97a.75.75 0 00-1.06-1.06l-3.97 3.97V2.5a.75.75 0 00-1.5 0v4.5zm0 11.25a.75.75 0 00-.75.75v4.5a.75.75 0 001.5 0v-2.69l3.97 3.97a.75.75 0 001.06-1.06l-3.97-3.97h3.69a.75.75 0 000-1.5H4a.75.75 0 00-.75.75zM16.75 4a.75.75 0 00.75-.75v-4.5a.75.75 0 00-1.5 0v2.69l-3.97-3.97a.75.75 0 00-1.06 1.06l3.97 3.97h-3.69a.75.75 0 000 1.5H16a.75.75 0 00.75-.75zm0 11.25a.75.75 0 00-.75.75h-4.5a.75.75 0 000 1.5h3.69l-3.97 3.97a.75.75 0 001.06 1.06l3.97-3.97v2.69a.75.75 0 001.5 0v-4.5z" />
                </svg>
             ) : (
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-3.5 h-3.5">
                   <path fillRule="evenodd" d="M2 3.75A.75.75 0 012.75 3h14.5a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75H2.75A.75.75 0 012 15.25V3.75zm1.5 11.75h13v-11h-13v11z" clipRule="evenodd" />
                </svg>
             )}
          </button>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white transition-colors"
          >
            {copied ? (
              <span className="text-green-500">Copied</span>
            ) : (
              <span>Copy</span>
            )}
          </button>
        </div>
      </div>
      <div className={`overflow-x-auto bg-[#09090b] ${isFullscreen ? 'flex-1 p-4' : 'p-4'}`}>
        <code className={clsx("font-mono text-sm text-zinc-300", className)} {...props}>
          {children}
        </code>
      </div>
    </div>
  );
};

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onFixCode }) => {
  const isUser = message.role === 'user';
  
  // Custom renderer for code to pass onFixCode handler
  const components = {
    code: (props: any) => <CodeBlock {...props} onFixCode={onFixCode} />
  };

  return (
    <div className={clsx(
      "flex w-full mb-8",
      isUser ? "justify-end" : "justify-start"
    )}>
      <div className={clsx(
        "max-w-[90%] md:max-w-[80%] lg:max-w-[70%]",
        "rounded-lg transition-all duration-200",
        isUser 
          ? "bg-zinc-800 text-white shadow-md border border-zinc-700 px-6 py-5" 
          : "bg-transparent text-zinc-300 pl-0 border-l-2 border-zinc-700 px-6 py-2"
      )}>
        <div className="flex items-center gap-2 mb-3">
          <div className={clsx(
            "w-2 h-2 rounded-full",
            isUser ? "bg-white" : "bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]"
          )} />
          <span className="text-xs font-mono font-medium text-zinc-500 uppercase tracking-widest">
            {isUser ? 'User' : 'Nano AI Studio'}
          </span>
          <span className="text-[10px] text-zinc-600 font-mono">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
        
        {/* User Attachments */}
        {message.attachments && message.attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
             {message.attachments.map((att, idx) => (
                att.mimeType.startsWith('image/') ? (
                   <img key={idx} src={`data:${att.mimeType};base64,${att.data}`} alt="attachment" className="max-w-[200px] rounded-md border border-zinc-700" />
                ) : (
                  <div key={idx} className="bg-zinc-900 border border-zinc-700 px-3 py-2 rounded flex items-center gap-2">
                     <span className="text-xs font-mono">{att.name || 'File'}</span>
                  </div>
                )
             ))}
          </div>
        )}

        {/* Generated Image */}
        {message.generatedImage && (
          <div className="mb-4">
             <img src={`data:image/jpeg;base64,${message.generatedImage}`} alt="Generated Content" className="w-full rounded-lg shadow-lg border border-zinc-800" />
          </div>
        )}

        {/* Generated Video */}
        {message.generatedVideo && (
          <div className="mb-4">
             <video 
               src={`${message.generatedVideo}&key=${process.env.API_KEY}`} 
               controls 
               autoPlay 
               loop
               className="w-full rounded-lg shadow-lg border border-zinc-800" 
             />
             <div className="text-[10px] text-zinc-500 mt-1">Video generated by Veo</div>
          </div>
        )}

        <div className="prose prose-invert prose-zinc max-w-none text-sm md:text-base leading-7">
          <ReactMarkdown 
            remarkPlugins={[remarkGfm]}
            components={components}
          >
            {message.content}
          </ReactMarkdown>
          
          {message.isStreaming && (
            <span className="inline-block w-2 h-4 ml-1 bg-indigo-500 animate-pulse align-middle shadow-[0_0_8px_rgba(99,102,241,0.5)]" />
          )}
        </div>

        {/* Grounding Sources */}
        {message.groundingMetadata && message.groundingMetadata.groundingChunks.length > 0 && (
          <div className="mt-4 pt-4 border-t border-zinc-800/50">
            <h4 className="text-xs font-mono text-zinc-500 mb-2 uppercase tracking-wider">Sources Found</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
               {message.groundingMetadata.groundingChunks.map((chunk, i) => chunk.web ? (
                 <a 
                   key={i} 
                   href={chunk.web.uri} 
                   target="_blank" 
                   rel="noreferrer"
                   className="flex items-center gap-2 p-2 rounded bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 transition-colors"
                 >
                   <img 
                      src={`https://www.google.com/s2/favicons?domain=${chunk.web.uri}`} 
                      alt="favicon" 
                      className="w-4 h-4 rounded-sm"
                      onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} 
                   />
                   <span className="text-xs text-zinc-400 truncate flex-1">{chunk.web.title}</span>
                 </a>
               ) : null)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
